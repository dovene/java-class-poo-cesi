package com.dov.cesi.factory;

public class Plane extends Engine {
    @Override
    public String carburant() {
        return "Kérosène";
    }
}
