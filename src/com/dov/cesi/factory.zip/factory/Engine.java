package com.dov.cesi.factory;

public abstract class Engine {
    public abstract String carburant();
}
