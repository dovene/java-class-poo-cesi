package com.dov.cesi.factory;

public class Bike extends Engine{
    @Override
    public String carburant() {
        return "Electricity";
    }
}
