package com.dov.cesi.factory;

public class Car extends Engine {
    @Override
    public String carburant() {
        return "Diesel/Essence";
    }
}
